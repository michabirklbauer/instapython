#!/usr/bin/env python3

name = "InstaPython"

from instagram import *
from instabot import *
from instaload import *
from instaview import *
